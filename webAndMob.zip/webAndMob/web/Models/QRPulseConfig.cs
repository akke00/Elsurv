﻿namespace web.Models
{
    public class QRPulseConfig
    {
        public string SysAdminLogin { get; set; }
        public string SysAdminPass { get; set; }
        public string SysCompanyId { get; set;}

    }
}
