﻿namespace web.Models
{
    public class UserData
    {
        public string? companyId { get; set; }
        public bool sysUser { get; set; } = false;
        public string? userId { get; set; }
        public string? login { get; set; }
        public string? name { get; set; }
    }
}
