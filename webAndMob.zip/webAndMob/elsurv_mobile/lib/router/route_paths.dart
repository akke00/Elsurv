class RoutePaths {
  static const String Splash = '/splash';
  static const String Home = '/home';
}
