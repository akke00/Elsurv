# elsurv_mobile

Mobile client for ElSurv System
